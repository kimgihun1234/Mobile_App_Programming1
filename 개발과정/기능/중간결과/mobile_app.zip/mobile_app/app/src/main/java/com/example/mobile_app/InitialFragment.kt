package com.example.mobile_app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.SystemClock
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.setFragmentResult
import com.example.mobile_app.databinding.FragmentInitialBinding
import kotlinx.coroutines.NonDisposableHandle.parent


class InitialFragment : Fragment() {
    private var _binding:FragmentInitialBinding?=null
    private val binding get()=_binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //val binding = FragmentInitialBinding.inflate(inflater,container,false)
        _binding=FragmentInitialBinding.inflate(inflater,container,false)
        binding.walktxt.text=""
        binding.walktxt.text=arguments?.getInt("key").toString()

        var get_walk_data = 0
        var initTime = 0L
        var pauseTime = 0L
        var tall = 170
        var button = 0
        binding.kmtxt.text = (get_walk_data*(tall*0.37)).toString()
        binding.start.setOnClickListener {
            if(button==0){
                binding.chronometer.base = SystemClock.elapsedRealtime() + pauseTime
                binding.chronometer.start()
                binding.walktxt.text=get_walk_data.toString()
                binding.start.text="stop"
                binding.start.isEnabled = true
                var isstart = "1"
                setFragmentResult("requestKey", bundleOf("bundleKey" to isstart))
                button=1
            }
            else{
                pauseTime = binding.chronometer.base - SystemClock.elapsedRealtime()
                binding.start.text="start"
                binding.chronometer.stop()
                binding.start.isEnabled = true
                var isstart = "0"
                setFragmentResult("requestKey", bundleOf("bundleKey" to isstart))
                button=0
            }
        }

        return binding.root
    }
}